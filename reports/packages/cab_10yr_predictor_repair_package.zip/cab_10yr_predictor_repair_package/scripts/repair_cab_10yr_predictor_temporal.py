#!/usr/bin/env python3
"""Repair CAB rolling-origin predictor with temporal held-out validation.

Inputs are provenance-clean row-level Parquet files generated from archived
ClinVar snapshots under ignored local directories. This script writes only
summary CSV/SVG outputs to tracked report locations.
"""

from __future__ import annotations

import csv
import hashlib
import math
from collections import Counter, defaultdict
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq


ROOT = Path(__file__).resolve().parents[1]
ROW_ROOT = ROOT / "data" / "rolling_10yr_real" / "processed"
FEATURE_ROOT = ROOT / "data" / "rolling_10yr_real_features"
TABLES = ROOT / "reports" / "tables"
FIGURES = ROOT / "reports" / "figures"
PRIMARY = "future_cross_environment_drift"
SECONDARY = [
    "future_condition_label_drift",
    "future_any_meaning_drift",
    "future_self_loop_stability",
    "future_unsupported_deterministic_reuse",
]
ENDPOINTS = [PRIMARY, *SECONDARY, "future_semantic_drift_without_reclassification"]


def read_parquet(path: Path) -> list[dict[str, object]]:
    return pq.read_table(path).to_pylist()


def write_csv(path: Path, rows: list[dict[str, object]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = []
        for row in rows:
            for key in row:
                if key not in fieldnames:
                    fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})


def write_parquet(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pq.write_table(pa.Table.from_pylist(rows), path, compression="zstd")


def origins() -> list[Path]:
    return sorted(path for path in ROW_ROOT.glob("origin_*") if (path / "baseline_assertions.parquet").exists())


def origin_year(origin_id: str) -> int:
    return int(origin_id.split("_")[1])


def load_origin(origin: Path) -> list[dict[str, object]]:
    baseline = read_parquet(origin / "baseline_assertions.parquet")
    endpoint = {row["variation_id"]: row for row in read_parquet(origin / "followup_endpoints.parquet")}
    rows = []
    for row in baseline:
        merged = dict(row)
        ep = endpoint.get(row["variation_id"], {})
        merged["future_condition_label_drift"] = bool(ep.get("condition_label_drift", False))
        merged["future_cross_environment_drift"] = bool(ep.get("future_cross_environment_drift", ep.get("cross_environment_drift", False)))
        merged["future_any_meaning_drift"] = bool(ep.get("any_meaning_drift", False))
        merged["future_self_loop_stability"] = bool(ep.get("self_loop_stable", False))
        merged["future_semantic_drift_without_reclassification"] = bool(ep.get("semantic_drift_without_reclassification", False))
        merged["future_unsupported_deterministic_reuse"] = bool(merged.get("cab_strict_direct_use_allowed")) and bool(merged["future_cross_environment_drift"])
        merged["origin_id"] = origin.name
        rows.append(merged)
    return rows


def norm(value: object) -> str:
    return str(value or "").strip().lower()


def condition_specificity(label: object) -> float:
    text = norm(label)
    if not text or "not provided" in text or "not specified" in text:
        return 0.0
    parts = [part for part in text.replace("|", ";").split(";") if part.strip()]
    if len(parts) >= 4:
        return 0.3
    if len(parts) == 1:
        return 1.0
    return 0.6


def feature_row(row: dict[str, object], gene_vocab: set[str] | None = None) -> dict[str, object]:
    regime = str(row["disease_architecture_regime"])
    label = norm(row["baseline_condition_label"])
    gene = str(row["gene"]).upper()
    if gene_vocab is not None and gene not in gene_vocab:
        gene = "OTHER"
    out = {
        "assertion_id": row["assertion_id"],
        "variation_id": row["variation_id"],
        "origin_id": row["origin_id"],
        "gene": gene,
        "domain": row["domain"],
        "baseline_environment": row["baseline_environment"],
        "disease_architecture_regime": regime,
        "review_status_baseline": row["baseline_review_status"],
        "submitter_count_baseline": int(row.get("baseline_submitter_count", 0) or 0),
        "log_submitter_count": math.log1p(int(row.get("baseline_submitter_count", 0) or 0)),
        "condition_specificity": condition_specificity(row["baseline_condition_label"]),
        "source_match_accepted": True,
        "meaning_match_accepted": True,
        "phenotype_domain_discordance_flag": False,
        "broad_or_unknown_label": "not provided" in label or "not specified" in label or row["baseline_environment"] == "unknown",
        "underresolved_flag": "underresolved" in regime,
        "structural_overlap_flag": "structural" in regime,
        "syndrome_organ_flag": "syndrome_organ" in regime,
        "modifier_penetrance_flag": "modifier" in regime or "penetrance" in regime,
        "cab_strict_direct_use_allowed": bool(row["cab_strict_direct_use_allowed"]),
        "cab_balanced_direct_use_allowed": bool(row["cab_balanced_direct_use_allowed"]),
        "cab_risk_score": float(row["cab_risk_score"]),
        "portability_score": 1.0 - float(row["cab_risk_score"]),
        "review_priority_score": 1.0 / max(1.0, float(row["cab_review_priority_rank"])),
    }
    for endpoint in ENDPOINTS:
        out[endpoint] = bool(row[endpoint])
    return out


def make_feature_matrices(all_rows_by_origin: dict[str, list[dict[str, object]]]) -> None:
    for origin_id, rows in all_rows_by_origin.items():
        gene_counts = Counter(str(row["gene"]).upper() for row in rows)
        vocab = {gene for gene, count in gene_counts.items() if count >= 5}
        features = [feature_row(row, vocab) for row in rows]
        write_parquet(FEATURE_ROOT / origin_id / "baseline_feature_matrix.parquet", features)


def endpoint_prevalence(all_features: dict[str, list[dict[str, object]]]) -> list[dict[str, object]]:
    rows = []
    for origin_id, records in all_features.items():
        n = len(records)
        row = {"origin_id": origin_id, "N": n}
        for endpoint in ENDPOINTS:
            c = sum(1 for record in records if record[endpoint])
            row[f"{endpoint}_N"] = c
            row[f"{endpoint}_prevalence"] = fmt(c / n if n else 0)
        rows.append(row)
    return rows


def rank_auc(y: list[int], scores: list[float]) -> float | str:
    n_pos = sum(y)
    n_neg = len(y) - n_pos
    if not n_pos or not n_neg:
        return ""
    pairs = sorted(zip(scores, y), key=lambda item: item[0])
    rank_sum = 0.0
    i = 0
    while i < len(pairs):
        j = i + 1
        while j < len(pairs) and pairs[j][0] == pairs[i][0]:
            j += 1
        avg_rank = (i + 1 + j) / 2
        rank_sum += avg_rank * sum(label for _, label in pairs[i:j])
        i = j
    return (rank_sum - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)


def auprc(y: list[int], scores: list[float]) -> float | str:
    if not sum(y):
        return ""
    pairs = sorted(zip(scores, y), reverse=True)
    tp = 0
    total = sum(y)
    area = 0.0
    last_recall = 0.0
    for i, (_, label) in enumerate(pairs, 1):
        if label:
            tp += 1
            recall = tp / total
            precision = tp / i
            area += precision * (recall - last_recall)
            last_recall = recall
    return area


def score_directionality(all_features: dict[str, list[dict[str, object]]]) -> list[dict[str, object]]:
    rows = []
    score_cols = ["regime_score", "cab_risk_score", "portability_score", "review_priority_score"]
    for origin_id, records in all_features.items():
        for endpoint in ENDPOINTS:
            y = [1 if record[endpoint] else 0 for record in records]
            for score in score_cols:
                vals = [score_value(record, score) for record in records]
                auc = rank_auc(y, vals)
                inv_auc = rank_auc(y, [-v for v in vals])
                preferred = "-score" if inv_auc != "" and auc != "" and float(inv_auc) > float(auc) else "score"
                rows.append({"origin_id": origin_id, "endpoint": endpoint, "score": score, "AUROC_score": fmt(auc), "AUROC_neg_score": fmt(inv_auc), "preferred_orientation": preferred})
    return rows


def score_value(row: dict[str, object], score: str) -> float:
    if score == "regime_score":
        return {
            "phenotype_anchored_monogenic": 0.0,
            "syndrome_anchored_self_loop": 0.0,
            "structural_functional_overlap": 0.6,
            "modifier_penetrance_boundary": 0.7,
            "syndrome_organ_boundary": 0.7,
            "nonspecific_underresolved": 0.9,
            "trigger_dependent_latent": 0.9,
            "pleiotropic_collision": 1.0,
        }.get(str(row["disease_architecture_regime"]), 0.5)
    return float(row[score])


def categories(train: list[dict[str, object]], fields: list[str], min_count: int = 100) -> dict[str, list[str]]:
    out = {}
    for field in fields:
        counts = Counter(str(row[field]) for row in train)
        out[field] = sorted(k for k, v in counts.items() if v >= min_count)
    return out


def vectorize(rows: list[dict[str, object]], feature_set: str, cats: dict[str, list[str]], coefficients: dict[str, float] | None = None) -> list[list[float]]:
    if coefficients is not None:
        fields_by_linear = {
            "metadata-only": ["review_status_baseline", "baseline_environment"],
            "gene-only": ["gene"],
            "regime-only": ["disease_architecture_regime"],
            "domain+environment-only": ["domain", "baseline_environment"],
            "gene+regime": ["gene", "disease_architecture_regime"],
            "gene+regime+metadata": ["gene", "disease_architecture_regime", "review_status_baseline"],
            "gene+environment+regime+metadata": ["gene", "baseline_environment", "disease_architecture_regime", "review_status_baseline"],
            "all-baseline-regularized": ["gene", "domain", "baseline_environment", "disease_architecture_regime", "review_status_baseline"],
            "routing-flags+regime": ["disease_architecture_regime", "domain"],
        }[feature_set]
        numeric_by_linear = {
            "metadata-only": ["log_submitter_count", "condition_specificity", "broad_or_unknown_label"],
            "gene-only": [],
            "regime-only": ["underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
            "domain+environment-only": [],
            "gene+regime": ["underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
            "gene+regime+metadata": ["log_submitter_count", "condition_specificity", "broad_or_unknown_label", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
            "gene+environment+regime+metadata": ["log_submitter_count", "condition_specificity", "broad_or_unknown_label", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
            "all-baseline-regularized": ["log_submitter_count", "condition_specificity", "source_match_accepted", "meaning_match_accepted", "phenotype_domain_discordance_flag", "broad_or_unknown_label", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag", "cab_strict_direct_use_allowed", "cab_balanced_direct_use_allowed"],
            "routing-flags+regime": ["source_match_accepted", "meaning_match_accepted", "phenotype_domain_discordance_flag", "cab_strict_direct_use_allowed", "cab_balanced_direct_use_allowed", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
        }[feature_set]
        vectors = []
        for row in rows:
            score = coefficients.get("__intercept__", 0.0)
            for field in fields_by_linear:
                value = str(row[field])
                score += coefficients.get(f"{field}={value}", coefficients.get(f"{field}=__OTHER__", 0.0))
            for field in numeric_by_linear:
                score += coefficients.get(field, 0.0) * float(row[field])
            vectors.append([score])
        return vectors
    fields_by_model = {
        "metadata-only": ["review_status_baseline"],
        "gene-only": ["gene"],
        "regime-only": ["disease_architecture_regime"],
        "domain+environment-only": ["domain", "baseline_environment"],
        "gene+regime": ["gene", "disease_architecture_regime"],
        "gene+regime+metadata": ["gene", "disease_architecture_regime", "review_status_baseline"],
        "gene+environment+regime+metadata": ["gene", "baseline_environment", "disease_architecture_regime", "review_status_baseline"],
        "all-baseline-regularized": ["gene", "domain", "baseline_environment", "disease_architecture_regime", "review_status_baseline"],
        "routing-flags+regime": ["disease_architecture_regime", "domain"],
    }[feature_set]
    numeric_by_model = {
        "metadata-only": ["log_submitter_count", "condition_specificity", "broad_or_unknown_label"],
        "gene-only": [],
        "regime-only": ["underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
        "domain+environment-only": [],
        "gene+regime": ["underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
        "gene+regime+metadata": ["log_submitter_count", "condition_specificity", "broad_or_unknown_label", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
        "gene+environment+regime+metadata": ["log_submitter_count", "condition_specificity", "broad_or_unknown_label", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
        "all-baseline-regularized": ["log_submitter_count", "condition_specificity", "source_match_accepted", "meaning_match_accepted", "phenotype_domain_discordance_flag", "broad_or_unknown_label", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag", "cab_strict_direct_use_allowed", "cab_balanced_direct_use_allowed"],
        "routing-flags+regime": ["source_match_accepted", "meaning_match_accepted", "phenotype_domain_discordance_flag", "cab_strict_direct_use_allowed", "cab_balanced_direct_use_allowed", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
    }[feature_set]
    vectors = []
    for row in rows:
        vec = [1.0]
        for field in fields_by_model:
            value = str(row[field])
            for cat in cats.get(field, []):
                vec.append(1.0 if value == cat else 0.0)
        for field in numeric_by_model:
            vec.append(float(row[field]))
        vectors.append(vec)
    return vectors


def train_logistic(x: list[list[float]], y: list[int], epochs: int = 80, lr: float = 0.05, l2: float = 1.0) -> list[float]:
    if not x:
        return []
    w = [0.0] * len(x[0])
    n = len(y)
    pos = sum(y)
    neg = n - pos
    pos_weight = neg / pos if pos else 1.0
    for _ in range(epochs):
        grad = [0.0] * len(w)
        for row, label in zip(x, y):
            p = sigmoid(dot(w, row))
            weight = pos_weight if label else 1.0
            err = (p - label) * weight
            for j, val in enumerate(row):
                grad[j] += err * val
        for j in range(1, len(w)):
            grad[j] += l2 * w[j]
        for j in range(len(w)):
            w[j] -= lr * grad[j] / n
    return w


def fit_naive_logit(train: list[dict[str, object]], y: list[int], feature_set: str) -> dict[str, float]:
    fields_by_model = {
        "metadata-only": ["review_status_baseline", "baseline_environment"],
        "gene-only": ["gene"],
        "regime-only": ["disease_architecture_regime"],
        "domain+environment-only": ["domain", "baseline_environment"],
        "gene+regime": ["gene", "disease_architecture_regime"],
        "gene+regime+metadata": ["gene", "disease_architecture_regime", "review_status_baseline"],
        "gene+environment+regime+metadata": ["gene", "baseline_environment", "disease_architecture_regime", "review_status_baseline"],
        "all-baseline-regularized": ["gene", "domain", "baseline_environment", "disease_architecture_regime", "review_status_baseline"],
        "routing-flags+regime": ["disease_architecture_regime", "domain"],
    }[feature_set]
    numeric_by_model = {
        "metadata-only": ["log_submitter_count", "condition_specificity", "broad_or_unknown_label"],
        "gene-only": [],
        "regime-only": ["underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
        "domain+environment-only": [],
        "gene+regime": ["underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
        "gene+regime+metadata": ["log_submitter_count", "condition_specificity", "broad_or_unknown_label", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
        "gene+environment+regime+metadata": ["log_submitter_count", "condition_specificity", "broad_or_unknown_label", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
        "all-baseline-regularized": ["log_submitter_count", "condition_specificity", "source_match_accepted", "meaning_match_accepted", "phenotype_domain_discordance_flag", "broad_or_unknown_label", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag", "cab_strict_direct_use_allowed", "cab_balanced_direct_use_allowed"],
        "routing-flags+regime": ["source_match_accepted", "meaning_match_accepted", "phenotype_domain_discordance_flag", "cab_strict_direct_use_allowed", "cab_balanced_direct_use_allowed", "underresolved_flag", "structural_overlap_flag", "syndrome_organ_flag", "modifier_penetrance_flag"],
    }[feature_set]
    n = len(y)
    pos = sum(y)
    base = (pos + 1) / (n + 2)
    coefs = {"__intercept__": logit(base)}
    global_logit = logit(base)
    for field in fields_by_model:
        groups = defaultdict(lambda: [0, 0])
        for row, label in zip(train, y):
            key = str(row[field])
            groups[key][0] += label
            groups[key][1] += 1
        for key, (p, total) in groups.items():
            if total < 25:
                continue
            coefs[f"{field}={key}"] = (logit((p + 2 * base) / (total + 2)) - global_logit) / max(1, len(fields_by_model))
        other_p = sum(p for _, (p, total) in groups.items() if total < 25)
        other_n = sum(total for _, (p, total) in groups.items() if total < 25)
        if other_n:
            coefs[f"{field}=__OTHER__"] = (logit((other_p + 2 * base) / (other_n + 2)) - global_logit) / max(1, len(fields_by_model))
    for field in numeric_by_model:
        vals = [float(row[field]) for row in train]
        mean = sum(vals) / len(vals)
        var = sum((v - mean) ** 2 for v in vals) / len(vals)
        if var == 0:
            continue
        cov = sum((v - mean) * (label - base) for v, label in zip(vals, y)) / len(vals)
        coefs[field] = max(-2.0, min(2.0, cov / var))
    return coefs


def logit(p: float) -> float:
    p = min(0.999999, max(0.000001, p))
    return math.log(p / (1 - p))


def sigmoid(x: float) -> float:
    if x < -30:
        return 0.0
    if x > 30:
        return 1.0
    return 1.0 / (1.0 + math.exp(-x))


def dot(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def predict(w: list[float], x: list[list[float]]) -> list[float]:
    return [sigmoid(dot(w, row)) for row in x]


def deterministic_random(key: object) -> float:
    return int(hashlib.sha256(str(key).encode()).hexdigest()[:8], 16) / 0xFFFFFFFF


def metrics(y: list[int], scores: list[float]) -> dict[str, object]:
    n = len(y)
    positives = sum(y)
    prevalence = positives / n if n else 0.0
    p5 = precision_at(y, scores, 0.05)
    p10 = precision_at(y, scores, 0.10)
    return {
        "N": n,
        "positives": positives,
        "endpoint_prevalence": fmt(prevalence),
        "AUROC": fmt(rank_auc(y, scores)),
        "AUPRC": fmt(auprc(y, scores)),
        "precision@5%": fmt(p5),
        "precision@10%": fmt(p10),
        "recall@5%": fmt(recall_at(y, scores, 0.05)),
        "recall@10%": fmt(recall_at(y, scores, 0.10)),
        "calibration": fmt(sum(scores) / n - prevalence if n else 0.0),
        "Brier_score": fmt(sum((s - yy) ** 2 for s, yy in zip(scores, y)) / n if n else 0.0),
        "enrichment_over_random": fmt(p10 / prevalence if prevalence else 0.0),
        "workload_to_capture_50%": fmt(workload_to_capture(y, scores, 0.50)),
    }


def precision_at(y: list[int], scores: list[float], frac: float) -> float:
    if not y:
        return 0.0
    k = max(1, math.ceil(len(y) * frac))
    idx = sorted(range(len(y)), key=lambda i: (-scores[i], i))[:k]
    return sum(y[i] for i in idx) / k


def recall_at(y: list[int], scores: list[float], frac: float) -> float:
    total = sum(y)
    if not total:
        return 0.0
    k = max(1, math.ceil(len(y) * frac))
    idx = sorted(range(len(y)), key=lambda i: (-scores[i], i))[:k]
    return sum(y[i] for i in idx) / total


def workload_to_capture(y: list[int], scores: list[float], target: float) -> float | str:
    total = sum(y)
    if not total:
        return ""
    found = 0
    for rank, i in enumerate(sorted(range(len(y)), key=lambda j: (-scores[j], j)), 1):
        found += y[i]
        if found >= total * target:
            return rank / len(y)
    return 1.0


def temporal_results(all_features: dict[str, list[dict[str, object]]], endpoint: str = PRIMARY, domain: str | None = None, era: str | None = None) -> list[dict[str, object]]:
    origin_ids = sorted(all_features, key=origin_year)
    model_names = ["random", "metadata-only", "gene-only", "regime-only", "domain+environment-only", "gene+regime", "gene+regime+metadata", "gene+environment+regime+metadata", "all-baseline-regularized"]
    rows = []
    for test_origin in origin_ids:
        train_origins = [o for o in origin_ids if origin_year(o) < origin_year(test_origin)]
        if not train_origins:
            continue
        train = [row for o in train_origins for row in all_features[o]]
        test = list(all_features[test_origin])
        if domain:
            train = [row for row in train if row["domain"] == domain]
            test = [row for row in test if row["domain"] == domain]
        if len(test) < 50 or len(train) < 100:
            rows.append({"origin_id": test_origin, "model": "all", "endpoint": endpoint, "domain": domain or "all", "era": era or era_for_origin(test_origin), "status": "underpowered", "N": len(test)})
            continue
        y_train = [1 if row[endpoint] else 0 for row in train]
        y_test = [1 if row[endpoint] else 0 for row in test]
        if not sum(y_train) or not sum(y_test) or sum(y_train) == len(y_train) or sum(y_test) == len(y_test):
            rows.append({"origin_id": test_origin, "model": "all", "endpoint": endpoint, "domain": domain or "all", "era": era or era_for_origin(test_origin), "status": "underpowered", "N": len(test), "positives": sum(y_test)})
            continue
        for model in model_names:
            if model == "random":
                scores = [deterministic_random(row["assertion_id"]) for row in test]
            else:
                coefs = fit_naive_logit(train, y_train, model)
                scores = [sigmoid(row[0]) for row in vectorize(test, model, {}, coefs)]
            metric = metrics(y_test, scores)
            row = {"origin_id": test_origin, "model": model, "endpoint": endpoint, "domain": domain or "all", "era": era or era_for_origin(test_origin), "status": "evaluated"}
            row.update(metric)
            rows.append(row)
    return rows


def routing_results(all_features: dict[str, list[dict[str, object]]]) -> list[dict[str, object]]:
    rows = []
    for endpoint in ["future_unsupported_deterministic_reuse", "future_any_meaning_drift"]:
        for row in temporal_results(all_features, endpoint=endpoint):
            row["predictor_family"] = "routing" if endpoint == "future_unsupported_deterministic_reuse" else "drift_secondary"
            rows.append(row)
    return rows


def incremental_value(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    by = {(row["origin_id"], row["model"]): row for row in rows if row.get("status") == "evaluated" and row.get("endpoint") == PRIMARY and row.get("domain") == "all"}
    comparisons = [("gene-only", "gene+regime"), ("metadata-only", "gene+regime+metadata"), ("gene+regime+metadata", "gene+environment+regime+metadata")]
    out = []
    deltas_by_comp = defaultdict(list)
    for origin in sorted({key[0] for key in by}):
        for base, plus in comparisons:
            if (origin, base) in by and (origin, plus) in by:
                b = by[(origin, base)]
                p = by[(origin, plus)]
                delta_auc = safe_float(p["AUROC"]) - safe_float(b["AUROC"])
                delta_auprc = safe_float(p["AUPRC"]) - safe_float(b["AUPRC"])
                delta_p10 = safe_float(p["precision@10%"]) - safe_float(b["precision@10%"])
                comp = f"{base}_vs_{plus}"
                deltas_by_comp[comp].append(delta_auc)
                out.append({"origin_id": origin, "comparison": comp, "delta_AUROC": fmt(delta_auc), "delta_AUPRC": fmt(delta_auprc), "delta_precision@10%": fmt(delta_p10), "training_fold_test": "not_applicable_no_hyperparameter_tuning"})
    for comp, vals in deltas_by_comp.items():
        mean = sum(vals) / len(vals)
        lo, hi = bootstrap_ci(vals)
        out.append({"origin_id": "pooled_across_test_origins", "comparison": comp, "delta_AUROC": fmt(mean), "delta_AUPRC": "", "delta_precision@10%": "", "bootstrap_CI_delta_AUROC": f"{fmt(lo)} to {fmt(hi)}", "training_fold_test": "paired bootstrap across held-out origins"})
    return out


def bootstrap_ci(vals: list[float]) -> tuple[float, float]:
    if not vals:
        return 0.0, 0.0
    samples = []
    for i in range(500):
        total = 0.0
        for j in range(len(vals)):
            idx = int(hashlib.sha256(f"{i}-{j}".encode()).hexdigest()[:8], 16) % len(vals)
            total += vals[idx]
        samples.append(total / len(vals))
    samples.sort()
    return samples[int(0.025 * len(samples))], samples[int(0.975 * len(samples)) - 1]


def era_for_origin(origin_id: str) -> str:
    year = origin_year(origin_id)
    if year < 2018:
        return "2015-2018"
    if year < 2021:
        return "2018-2021"
    return "2021-2026"


def domain_results(all_features: dict[str, list[dict[str, object]]]) -> list[dict[str, object]]:
    out = []
    for domain in ["inherited_arrhythmia", "cardiomyopathy", "hereditary_cancer"]:
        rows = temporal_results(all_features, domain=domain)
        out.extend(rows)
    return out


def era_results(nested_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped = defaultdict(list)
    for row in nested_rows:
        if row.get("status") == "evaluated":
            grouped[(row["era"], row["model"])].append(row)
    out = []
    for (era, model), rows in sorted(grouped.items()):
        out.append({
            "era": era,
            "model": model,
            "test_origins": len(rows),
            "mean_AUROC": fmt(mean_safe(row["AUROC"] for row in rows)),
            "mean_AUPRC": fmt(mean_safe(row["AUPRC"] for row in rows)),
            "mean_precision@10%": fmt(mean_safe(row["precision@10%"] for row in rows)),
            "mean_enrichment_over_random": fmt(mean_safe(row["enrichment_over_random"] for row in rows)),
        })
    return out


def review_queue(nested_rows: list[dict[str, object]], all_features: dict[str, list[dict[str, object]]]) -> list[dict[str, object]]:
    # Refit only the policy models needed for queues so the output records all budgets.
    rows = []
    policy_map = {
        "random": "random",
        "metadata-only": "metadata-only",
        "gene-only": "gene-only",
        "regime-only": "regime-only",
        "gene+regime": "gene+regime",
        "full baseline predictor": "all-baseline-regularized",
    }
    origin_ids = sorted(all_features, key=origin_year)
    for test_origin in origin_ids:
        train_origins = [o for o in origin_ids if origin_year(o) < origin_year(test_origin)]
        if not train_origins:
            continue
        train = [row for o in train_origins for row in all_features[o]]
        test = all_features[test_origin]
        y_train = [1 if row[PRIMARY] else 0 for row in train]
        y_test = [1 if row[PRIMARY] else 0 for row in test]
        if not sum(y_train) or not sum(y_test):
            continue
        scores_by_policy = {}
        for policy, model in policy_map.items():
            if model == "random":
                scores_by_policy[policy] = [deterministic_random(row["assertion_id"]) for row in test]
            else:
                coefs = fit_naive_logit(train, y_train, model)
                scores_by_policy[policy] = [sigmoid(row[0]) for row in vectorize(test, model, {}, coefs)]
        prevalence = sum(y_test) / len(y_test)
        for policy, scores in scores_by_policy.items():
            for budget in [0.05, 0.10, 0.20]:
                precision = precision_at(y_test, scores, budget)
                rows.append({"origin_id": test_origin, "policy": policy, "endpoint": PRIMARY, "budget": budget, "precision@K": fmt(precision), "recall@K": fmt(recall_at(y_test, scores, budget)), "enrichment_over_random": fmt(precision / prevalence if prevalence else 0.0), "workload_to_capture_50%": fmt(workload_to_capture(y_test, scores, 0.50))})
    return rows


def publication_claims(incremental_rows: list[dict[str, object]], nested_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    pooled = [row for row in incremental_rows if row["origin_id"] == "pooled_across_test_origins" and "gene-only_vs_gene+regime" in row["comparison"]]
    supported = bool(pooled and safe_float(pooled[0]["delta_AUROC"]) > 0)
    full = [row for row in nested_rows if row.get("model") == "all-baseline-regularized" and row.get("status") == "evaluated"]
    full_mean = mean_safe(row["AUROC"] for row in full)
    return [
        {"claim": "CAB regime features add incremental predictive information beyond gene-only for future cross-environment drift.", "status": "allowed_if_supported" if supported else "not_supported_by_current_held_out_results", "publication_safe_note": "Use only if pooled held-out delta AUROC/AUPRC is positive and CI is acceptable."},
        {"claim": "CAB improves top-K review prioritization for future boundary-crossing assertions.", "status": "allowed_if_supported" if full_mean > 0.5 else "not_supported_by_current_held_out_results", "publication_safe_note": "Use only if held-out review queue enrichment exceeds random."},
        {"claim": "Historical prospective emulation supports disease architecture as a predictor of assertion portability.", "status": "allowed_if_supported" if supported else "not_supported_by_current_held_out_results", "publication_safe_note": "Historical prospective emulation only; not clinical prospective validation."},
        {"claim": "Static CAB rule score did not predict future drift, but one-hot temporal models reveal or fail to reveal incremental regime signal.", "status": "allowed", "publication_safe_note": "Honest interpretation tied to held-out temporal tables."},
        {"claim": "CAB is better supported as a routing framework than as a longitudinal drift predictor.", "status": "allowed_if_supported", "publication_safe_note": "Use if routing target performance exceeds drift target performance."},
        {"claim": "CAB provides true prospective validation.", "status": "forbidden", "publication_safe_note": "Do not claim true prospective validation."},
        {"claim": "CAB predicts clinical outcomes, patient risk, or tuned-on-test performance.", "status": "forbidden", "publication_safe_note": "No patient outcomes are modeled; test windows are held out."},
    ]


def svg_queue(path: Path, queue_rows: list[dict[str, object]]) -> None:
    grouped = defaultdict(list)
    for row in queue_rows:
        if str(row["budget"]) == "0.1":
            grouped[row["policy"]].append(safe_float(row["enrichment_over_random"]))
    labels = list(grouped)
    vals = [mean_safe(v) for v in grouped.values()]
    width, height = 920, 420
    maxv = max(vals) if vals else 1
    bars = []
    for i, (label, value) in enumerate(zip(labels, vals)):
        x = 60 + i * 130
        h = 270 * value / maxv if maxv else 0
        y = 350 - h
        bars.append(f'<rect x="{x}" y="{y:.1f}" width="52" height="{h:.1f}" fill="#4c72b0"/><text x="{x}" y="372" font-size="10" transform="rotate(35 {x},372)">{label}</text><text x="{x}" y="{y-5:.1f}" font-size="10">{value:.2f}</text>')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"><text x="24" y="28" font-size="18">Held-out review queue enrichment at top 10%</text>{"".join(bars)}</svg>', encoding="utf-8")


def fmt(value: object) -> str:
    if value == "":
        return ""
    return f"{float(value):.6f}" if isinstance(value, float) else str(value)


def safe_float(value: object) -> float:
    try:
        return float(value)
    except Exception:
        return 0.0


def mean_safe(values) -> float:
    vals = [safe_float(value) for value in values if value != ""]
    return sum(vals) / len(vals) if vals else 0.0


def main() -> None:
    all_rows = {origin.name: load_origin(origin) for origin in origins()}
    make_feature_matrices(all_rows)
    all_features = {origin_id: [feature_row(row) for row in rows] for origin_id, rows in all_rows.items()}
    write_csv(TABLES / "predictor_endpoint_prevalence_by_origin.csv", endpoint_prevalence(all_features))
    write_csv(TABLES / "predictor_score_directionality_audit.csv", score_directionality(all_features))
    nested = temporal_results(all_features)
    routing = routing_results(all_features)
    write_csv(TABLES / "predictor_temporal_nested_results.csv", nested + routing)
    incremental = incremental_value(nested)
    write_csv(TABLES / "predictor_incremental_value_of_regime.csv", incremental)
    write_csv(TABLES / "predictor_domain_stratified_results.csv", domain_results(all_features))
    write_csv(TABLES / "predictor_era_stratified_results.csv", era_results(nested))
    queue_rows = review_queue(nested, all_features)
    write_csv(TABLES / "predictor_review_queue_validation.csv", queue_rows)
    svg_queue(FIGURES / "predictor_review_queue_capture.svg", queue_rows)
    write_csv(TABLES / "predictor_publication_safe_claims.csv", publication_claims(incremental, nested))
    print(f"Origins: {len(all_features)}")
    print(f"Feature rows: {sum(len(rows) for rows in all_features.values())}")


if __name__ == "__main__":
    main()

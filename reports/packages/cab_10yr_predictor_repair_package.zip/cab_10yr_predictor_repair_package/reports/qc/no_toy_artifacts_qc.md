# No disallowed rolling-origin artifacts QC

- pass: no path contains disallowed legacy toy directory token (matches=0)
- pass: no tracked report/table path contains disallowed fixture outputs (matches=0)
- pass: no row-level CSV is tracked for rolling-origin analysis (matches=0)
- pass: real row-level outputs are under ignored Parquet paths
- pass: leakage audit summary contains only `pass` statuses
- pass: artifact manifest marks row-level real outputs `tracked_in_git=no`
- pass: publication claims use historical prospective emulation / temporal backtesting wording

Allowed interpretation: historical prospective emulation from archived ClinVar snapshots.

# CAB 10-year predictor repair package

This package repairs the rolling-origin predictor by separating static CAB routing scores from held-out temporal prediction.

## What changed

- Audited endpoint prevalence by origin.
- Audited score directionality for static CAB scores and documented cases where `-score` is the better orientation.
- Built ignored row-level one-hot baseline feature matrices under `data/rolling_10yr_real_features/{origin_id}/baseline_feature_matrix.parquet` (not included here).
- Ran temporal nested validation: train on earlier origins, test on later origins only.
- Evaluated drift and routing predictor families separately.
- Added incremental value tests for regime features beyond gene-only / metadata-only baselines.
- Added domain-stratified, era-stratified, and review queue validation outputs.
- Added honest publication-safe claims.

## Included outputs

- `reports/tables/predictor_endpoint_prevalence_by_origin.csv`
- `reports/tables/predictor_score_directionality_audit.csv`
- `reports/tables/predictor_temporal_nested_results.csv`
- `reports/tables/predictor_incremental_value_of_regime.csv`
- `reports/tables/predictor_domain_stratified_results.csv`
- `reports/tables/predictor_era_stratified_results.csv`
- `reports/tables/predictor_review_queue_validation.csv`
- `reports/tables/predictor_publication_safe_claims.csv`
- `reports/figures/predictor_review_queue_capture.svg`

## Not included

- No raw ClinVar downloads.
- No row-level Parquet feature matrices.
- No row-level baseline/endpoints Parquet.
- No toy/dry-run/synthetic rolling-origin datasets.

## Key held-out summary

For future cross-environment drift over 11 testable held-out origins:

- random AUROC ≈ 0.4924
- gene-only AUROC ≈ 0.5781
- regime-only AUROC ≈ 0.6998
- gene+regime AUROC ≈ 0.7164
- all-baseline regularized-style score AUROC ≈ 0.7419

Incremental held-out delta for gene-only vs gene+regime:

- mean delta AUROC ≈ +0.1383
- paired bootstrap CI across origins: 0.1066 to 0.1627

Interpretation remains historical prospective emulation / temporal backtesting only, not true prospective clinical validation.

from cab_portability.routing import final_direct_for_mode


def test_strict_blocks_underresolved_inline_unit_record():
    row = {
        "disease_architecture_regime": "nonspecific_underresolved",
        "source_match_accepted": "True",
        "meaning_match_accepted": "True",
        "phenotype_domain_discordance_flag": "False",
        "baseline_environment": "Brugada syndrome",
        "cab_strict_direct_use_allowed": "True",
        "cab_balanced_direct_use_allowed": "True",
    }

    assert final_direct_for_mode(row, "CAB-Strict")[0] is False
    assert final_direct_for_mode(row, "CAB-Balanced")[0] is False


def test_direct_use_blocks_rejected_meaning_inline_unit_record():
    row = {
        "disease_architecture_regime": "phenotype_anchored_monogenic",
        "source_match_accepted": "True",
        "meaning_match_accepted": "False",
        "phenotype_domain_discordance_flag": "False",
        "baseline_environment": "HCM",
        "cab_strict_direct_use_allowed": "True",
        "cab_balanced_direct_use_allowed": "True",
    }

    assert final_direct_for_mode(row, "CAB-Strict")[0] is False
    assert final_direct_for_mode(row, "CAB-Balanced")[0] is False


def test_strict_allows_concordant_anchored_inline_unit_record():
    row = {
        "disease_architecture_regime": "phenotype_anchored_monogenic",
        "source_match_accepted": "True",
        "meaning_match_accepted": "True",
        "phenotype_domain_discordance_flag": "False",
        "baseline_environment": "HCM",
        "cab_strict_direct_use_allowed": "True",
        "cab_balanced_direct_use_allowed": "True",
    }

    assert final_direct_for_mode(row, "CAB-Strict")[0] is True
    assert final_direct_for_mode(row, "CAB-Balanced")[0] is True
